import {fileURLToPath} from 'node:url';
process.argv.push('--root',fileURLToPath(new URL('./site',import.meta.url)));
await import('./runtime/serve.mjs');
