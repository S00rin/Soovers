'use client';
import {lazy,Suspense,useEffect,useState} from 'react';
import F5Academy from './education/F5Academy';
const TowerApp=lazy(()=>import('./tower/TowerApp'));
export default function SooVersApp(){const [tower,setTower]=useState(false);useEffect(()=>{const sync=()=>setTower(location.hash==='#tower');sync();window.addEventListener('hashchange',sync);return()=>window.removeEventListener('hashchange',sync);},[]);return tower?<Suspense fallback={<div className="load-world">در حال ورود به جهان سورین…</div>}><TowerApp/></Suspense>:<F5Academy/>;}
